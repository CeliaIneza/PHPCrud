<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body onload="print()">
<div class="container">
<hr>
<table>
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Password</th>
<th>Email</th>
<th>Number</th>
</tr>
</thead>
<tbody>
<?php
include "connection.php";
$get_list=mysqli_query($conn,"SELECT * FROM studii");
while($row=mysqli_fetch_array($get_list)){
?>
<tr>
<td><?php echo $row['id']?></td>
<td><?php echo $row['name']?></td>
<td><?php echo $row['password']?></td>
<td><?php echo $row['email']?></td>
<td><?php echo $row['number']?></td>
</tr>
<?php
}
?>
</tbody>
</table>
</body>
</html>