<?php
include 'connection.php';

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $number = $_POST['number'];

    $sql = "INSERT INTO studii(name,password,email,number) VALUES('$name','$password','$email','$number')";

    $result = mysqli_query($conn,$sql);
    if($result){
        // echo"new data is inside";
        header('location:display.php');
    }else{
        die(mysqli_error($result));
    }
}
?>