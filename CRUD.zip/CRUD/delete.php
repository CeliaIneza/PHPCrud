<?php

include 'connection.php';

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "DELETE FROM studii WHERE id = $id";
    $result = mysqli_query($conn,$sql);

    if($result){
        // echo"done deleted";
        header("location:display.php");
    }else{
        die(mysqli_error($conn));
    }
}

?>