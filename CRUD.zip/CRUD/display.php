<?php
include 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style></style>
</head>
<body>
    <div class="container">
        <button id="user"><a href="signup.html">add user</a></button>
        
        <table style="border:2px solid black; cell-spacing:0; cell-padding:2px;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>PASSWORD</th>
                    <th>EMAIL</th>
                    <th>NUMBER</th>
                    <th>OPERATIONS</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM studii";
                $result = mysqli_query($conn,$sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){
                ?>
                <tr>
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['name']?></td>
                    <td><?php echo $row['password']?></td>
                    <td><?php echo $row['email']?></td>
                    <td><?php echo $row['number']?></td>
                    <td><a href="delete.php?id=<?php echo $row['id']?>" id="delete">Delete</a>
                    <button><a href="update.html">update</a></button></td>
                </tr>
                
<?php
  };
} 
?>
                
            </tbody>
        </table>
        <button><a href="convert.php" class="convo">Pdf View</a></button><br><br>
        <button><a href="download.php" class="convo">xcls view</a></button>
    </div>
</body>
</html>