<?php
include 'connection.php';

$result = $conn->query("SELECT * FROM studii");
if ($result->num_rows > 0) {
$delimiter = ",";
$filename = "users" . date('Y-m-d') . ".csv";
$f = fopen('php://memory', 'w');
$fields = array('id', 'name', 'password', 'email', 'number');
fputcsv($f, $fields, $delimiter);
while ($row = $result->fetch_assoc()) {
$lineData = array($row['id'], $row['name'], $row['password'], $row['email'], $row['number']);
fputcsv($f, $lineData, $delimiter);
}
fseek($f, 0);
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename='.$filename.';');
fpassthru($f);
exit;
}
header("Location: display.php");
exit;
?>