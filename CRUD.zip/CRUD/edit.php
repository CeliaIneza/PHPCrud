<?php

include 'connection.php';

if(isset($_POST['update'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $sql = "UPDATE studii SET id = '$id',name = '$name',password = '$password',email = '$email',number = '$number' WHERE id = '$id'";

    $result = mysqli_query($conn,$sql);

    if($result){
        // echo"done updated";
        header("location:display.php");
    }else{
        die(mysqli_error($conn));
    }
}

?>


